const appname = "eMart";
const appversion = "Version 1.0.0";
const credits = "@Baaba Devs";
const email = "Email";
const emailHint = "admin@admin.com";
const password = "password";
const passwordHint = "*****";
const forgotpass  = "Forgot Password";
const login = "Log in";
const signup = "Sign up";
const createNewAccount = "or, create a new account";
const loginWith = "log in with";
const retypePassword = "Retype Passowrd";
const name = "name";
const nameHint = "Abubakr";
const privacyPolicy = "Privacy Policy ";
const termAndcond = "Terms  and Conditions ";
const alreadyHaveAccount = "Already have an account ? ";

const home="Home", categories="Categories", cart="Cart", account="Account";


const searchanything = "Search anything...",
    todayDeal = "Today's Deal",
    flashsale = "Flash Sale",
    topSellers = "Top Sellers",
    brands = "Brands",
    topCategories = "Top Categories" ,
    featuresCategories = "Featured Categories",
    cricket = "Cricket",
    girlsWatches = "Girls Watches",
    mobilePhone = "Mobile Phone",
    boysGlasses = "Boys Glasses",
    tShirts = "TShirts",
    girlsDress = "Girls Dresses";


const featuredProdcut = "Feature Product";


// categories String

const womenClothing = "Women Clothing",
    Swimming = "Swimming",
    Badminton = "Badminton",
    shoes = "Shoes",
    kids= "Kids",
    Ball_Games = "Ball Games",
    Gym= "Gym",
    Apparels = "Apparels",
    IndoorGames = "Indoor Games";



const vedio = "Vedio",
    reviews = "Reviews",
    sellerPolicy = "Seller Policy",
    returnPolicy = "Return Policy",
    productyoulike = "Products you may also like",
    supportPolicy = "Support Policy";


const wishList = "My Whishlist",
    orders = "My Orders",
    messages = "Messages",
    oldpass = 'Old Password',
    newpass = 'New Password';


const paypal = "Paypal", paytm = "Paytm", cod = "Cash On Delivary";




