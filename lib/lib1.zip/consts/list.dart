import 'package:signature/consts/consts.dart';

const socialIconList = [
  icFacebookLogo,icGoogleLogo,icTwitterLogo
];


//const slidersList = [imgSlider1,imgSlider2,imgSlider3,imgSlider4];
const slidersList = [n1,n2,n3,n4];

// const secondslidersList = [imgSs1,imgSs2,imgSs3,imgSs4];

const secondslidersList = [nn1,nn2,nn3,nn4];


const featuredImage1 = [imgS1,imgS2,imgS3];

const featuredImage2 = [imgS4,imgS5,imgS6];

const featuredTitle1 = [cricket,girlsDress,girlsWatches];

const featuredTitle2 = [boysGlasses,mobilePhone,tShirts];


const categoriesLsit = [
  cricket,Swimming,Badminton,shoes,kids,Ball_Games,Gym,Apparels,IndoorGames
];

const categoriesImages = [
  imgS1,imgFc1,imgFc2,imgFc3,imgFc4,imgFc5,imgS11,imgFc6,imgFc9,
];


const itemDetailButton = [vedio,reviews,privacyPolicy,returnPolicy,supportPolicy];


const profileButtonsList = [orders,wishList,messages];

const profileButtonsIcon = [icOrder,icOrder,icMessages];


const paymentMethodsImg = [imgPaypal,imgPaytm,imgCod];
const paymentMethods = [paypal,paytm,cod];
